import AdminLayout from "@/components/layout";
import { BasicCompanyRequestTable } from "@/components/requestTable";
import { fetcher } from "@/utils/swr_fetcher";
import { Container, Typography } from "@mui/material";
import React from "react";
import useSWR from "swr";

export default function Index() {
  const { data, error, isLoading } = useSWR("/admin/companies", fetcher);
  return (
    <Container>
      <Typography variant="h5" gutterBottom>
        Recent Requests
      </Typography>
      <BasicCompanyRequestTable data={data ? data : []} />
    </Container>
  );
}

Index.getLayout = function (page) {
  return <AdminLayout>{page}</AdminLayout>;
};
